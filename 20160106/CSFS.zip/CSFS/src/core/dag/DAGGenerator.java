package core.dag;

/*
 * The generator for resulting DAG schedule 
 */
public class DAGGenerator {
	
	
	
	
	
}
